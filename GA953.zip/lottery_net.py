"""
lottery_engine/sources/lottery_net.py

Parser for lottery.net — primary historical source (priority 1).

URL pattern (corrected):
    https://www.lottery.net/{state_slug}/{game_slug}/numbers/{year}

Each URL is a per-draw-time, per-year page. lottery.net uses distinct
game slugs for each draw time slot, e.g.:
    georgia/cash-3-midday/numbers/2024
    georgia/cash-3-evening/numbers/2024
    georgia/cash-3-night/numbers/2024

Because pages are yearly (not monthly), this parser fetches the full year
page once and caches it in memory. fetch_month() slices cached results to
the requested (year, month) before returning, so the base class's
date_range_months loop works without hitting the same URL 12 times.

Since each page covers exactly one draw time, all results on the page
take their draw_time directly from mapping.job_def.draw_time — no
column-splitting or draw-time detection is needed.

HTML structure (as observed on lottery.net):
    Results appear in a <ul>/<ol> list or <table>. Each entry carries:
      - a date element  (<time>, <span class="date">, or a <td>)
      - a number element (individual digit <span>s, a "N-N-N" string,
        or a single digits text node)

Parser strategy:
    1. Digit-ball list   — <li> items with per-digit <span class="ball">
    2. Structured table  — <table> with date + number columns
    3. Result list items — generic date+number container elements
    4. JSON-LD           — structured data blocks in <script> tags
"""
from __future__ import annotations
import json
import logging
import re

from bs4 import BeautifulSoup, Tag

from registry.models import SourceJobMapping
from registry.enums import SourceName, SOURCE_PRIORITIES
from sources.base import SourceParser, RawDrawResult, normalize_number, now_utc_iso
from sources.draw_time_map import normalize_draw_time

logger = logging.getLogger(__name__)


class LotteryNetParser(SourceParser):
    source_name     = SourceName.LOTTERY_NET
    source_priority = SOURCE_PRIORITIES[SourceName.LOTTERY_NET]

    def __init__(self) -> None:
        super().__init__()
        # Cache keyed by URL so a year page is fetched only once
        # even when fetch_month is called 12 times for the same year.
        self._page_cache: dict[str, list[RawDrawResult]] = {}

    # ------------------------------------------------------------------
    # fetch_month — called by base class for every (year, month) in range
    # ------------------------------------------------------------------

    def fetch_month(
        self,
        mapping: SourceJobMapping,
        year: int,
        month: int,
    ) -> list[RawDrawResult]:
        """
        Fetch one month's results.
        Internally fetches the full year page (with caching) and slices.
        The {month} value in build_url() is passed through but the yearly
        URL template ignores it — only {year} is used.
        """
        url = mapping.build_url(year=year, month=month)
        if not url:
            logger.warning("No URL template for %s", mapping.job_def.draw_label)
            return []

        if url not in self._page_cache:
            self._page_cache[url] = self._fetch_year_page(url, mapping)

        month_prefix = f"{year}-{month:02d}"
        results = [
            r for r in self._page_cache[url]
            if r.draw_date.startswith(month_prefix)
        ]

        logger.info(
            "  lottery.net: %d results  %s %s %d/%02d  [%s]",
            len(results),
            mapping.job_def.state,
            mapping.job_def.game_type,
            year, month,
            mapping.source_game_slug,
        )
        return results

    def clear_cache(self) -> None:
        """Clear the year-page cache (useful between large backfill runs)."""
        self._page_cache.clear()

    # ------------------------------------------------------------------
    # Fetch and parse one full year page
    # ------------------------------------------------------------------

    def _fetch_year_page(
        self,
        url: str,
        mapping: SourceJobMapping,
    ) -> list[RawDrawResult]:
        resp = self._get(url)
        if resp is None:
            logger.warning("  lottery.net: failed to fetch %s", url)
            return []

        soup = BeautifulSoup(resp.text, "html.parser")

        for strategy in (
            self._parse_ball_list,
            self._parse_results_table,
            self._parse_result_entries,
            self._parse_json_ld,
        ):
            try:
                results = strategy(soup, mapping, url)
                if results:
                    logger.debug(
                        "  lottery.net: strategy %s returned %d rows for %s",
                        strategy.__name__, len(results), url,
                    )
                    return results
            except Exception as exc:
                logger.debug("  lottery.net: strategy %s failed: %s", strategy.__name__, exc)

        logger.warning("  lottery.net: all strategies returned 0 rows for %s", url)
        return []

    # ------------------------------------------------------------------
    # Strategy 1: digit-ball list
    #
    # lottery.net commonly renders numbers as individual digit balls:
    #
    #   <li class="c-result-item">
    #     <time class="c-result-date" datetime="2024-01-15">Mon, Jan 15</time>
    #     <ul class="c-balls">
    #       <li class="c-ball">1</li>
    #       <li class="c-ball">2</li>
    #       <li class="c-ball">3</li>
    #     </ul>
    #   </li>
    # ------------------------------------------------------------------

    def _parse_ball_list(
        self,
        soup: BeautifulSoup,
        mapping: SourceJobMapping,
        url: str,
    ) -> list[RawDrawResult]:
        results: list[RawDrawResult] = []
        now = now_utc_iso()
        canonical_time = mapping.job_def.draw_time

        items = soup.find_all(
            lambda tag: tag.name in ("li", "div", "article")
            and tag.get("class")
            and any(
                re.search(r"result|draw|item|entry", c, re.I)
                for c in tag.get("class", [])
            )
        )

        for item in items:
            try:
                draw_date = _extract_date(item)
                if not draw_date:
                    continue

                balls = item.find_all(
                    lambda t: t.name in ("li", "span", "div")
                    and t.get("class")
                    and any(re.search(r"ball|digit|num", c, re.I)
                            for c in t.get("class", []))
                )
                if balls:
                    number = normalize_number(
                        "".join(b.get_text(strip=True) for b in balls)
                    )
                else:
                    number = _extract_inline_number(item, mapping.job_def.game_type)

                if not number or not _valid_length(number, mapping.job_def.game_type):
                    continue

                results.append(_make_result(
                    mapping, draw_date, canonical_time, number, url, now,
                    raw_label=mapping.source_draw_time_label or canonical_time,
                ))
            except Exception:
                continue

        return results

    # ------------------------------------------------------------------
    # Strategy 2: results table
    # ------------------------------------------------------------------

    def _parse_results_table(
        self,
        soup: BeautifulSoup,
        mapping: SourceJobMapping,
        url: str,
    ) -> list[RawDrawResult]:
        results: list[RawDrawResult] = []
        now = now_utc_iso()
        canonical_time = mapping.job_def.draw_time

        for table in soup.find_all("table"):
            headers = _table_headers(table)
            if not headers:
                continue

            date_col   = _col_index(headers, ("date", "day", "drawn"))
            number_col = _col_index(headers, ("number", "result", "winning", "draw", "pick"))

            if date_col is None:
                date_col = 0
            if number_col is None:
                number_col = 1 if len(headers) > 1 else 0

            body = table.find("tbody") or table
            for row in body.find_all("tr"):
                cells = row.find_all(["td", "th"])
                if len(cells) <= max(date_col, number_col):
                    continue
                try:
                    draw_date = _parse_date_text(cells[date_col].get_text(strip=True))
                    if not draw_date:
                        continue

                    num_cell = cells[number_col]
                    balls = num_cell.find_all(
                        lambda t: t.name in ("span", "li", "div")
                        and any(re.search(r"ball|digit", c, re.I)
                                for c in t.get("class", []))
                    )
                    raw_num = (
                        "".join(b.get_text(strip=True) for b in balls)
                        if balls
                        else num_cell.get_text(strip=True)
                    )
                    number = normalize_number(raw_num)
                    if not _valid_length(number, mapping.job_def.game_type):
                        continue

                    results.append(_make_result(
                        mapping, draw_date, canonical_time, number, url, now,
                        raw_label=mapping.source_draw_time_label or canonical_time,
                    ))
                except Exception:
                    continue

        return results

    # ------------------------------------------------------------------
    # Strategy 3: generic result entry containers
    # ------------------------------------------------------------------

    def _parse_result_entries(
        self,
        soup: BeautifulSoup,
        mapping: SourceJobMapping,
        url: str,
    ) -> list[RawDrawResult]:
        results: list[RawDrawResult] = []
        now = now_utc_iso()
        canonical_time = mapping.job_def.draw_time

        containers = soup.find_all(
            class_=re.compile(r"result|draw|winning|lottery", re.I)
        )
        for c in containers:
            try:
                draw_date = _extract_date(c)
                if not draw_date:
                    continue
                number = _extract_inline_number(c, mapping.job_def.game_type)
                if not number:
                    continue
                results.append(_make_result(
                    mapping, draw_date, canonical_time, number, url, now,
                    raw_label=mapping.source_draw_time_label or canonical_time,
                ))
            except Exception:
                continue

        return results

    # ------------------------------------------------------------------
    # Strategy 4: JSON-LD structured data
    # ------------------------------------------------------------------

    def _parse_json_ld(
        self,
        soup: BeautifulSoup,
        mapping: SourceJobMapping,
        url: str,
    ) -> list[RawDrawResult]:
        results: list[RawDrawResult] = []
        now = now_utc_iso()
        canonical_time = mapping.job_def.draw_time

        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string or "")
                items = data if isinstance(data, list) else [data]
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    raw_date   = item.get("startDate") or item.get("date")
                    raw_number = (
                        item.get("result") or item.get("name") or item.get("number")
                    )
                    if not raw_date or not raw_number:
                        continue
                    draw_date = _parse_date_text(str(raw_date))
                    if not draw_date:
                        continue
                    number = normalize_number(str(raw_number))
                    if not _valid_length(number, mapping.job_def.game_type):
                        continue
                    results.append(_make_result(
                        mapping, draw_date, canonical_time, number, url, now,
                        raw_label=mapping.source_draw_time_label or canonical_time,
                    ))
            except Exception:
                continue

        return results


# ------------------------------------------------------------------
# Module-level parsing utilities (also imported by lotterycorner.py
# and lotteryusa.py for _parse_date_text / _valid_length)
# ------------------------------------------------------------------

_DATE_FMTS = [
    "%Y-%m-%d",
    "%m/%d/%Y",
    "%B %d, %Y",
    "%b %d, %Y",
    "%d-%b-%Y",
    "%Y/%m/%d",
    "%m-%d-%Y",
    "%d/%m/%Y",
]


def _parse_date_text(raw: str) -> str | None:
    """Parse any common date string to YYYY-MM-DD. Returns None on failure."""
    if not raw:
        return None
    raw = raw.strip()
    m = re.match(r"(\d{4}-\d{2}-\d{2})", raw)
    if m:
        return m.group(1)
    from datetime import datetime as _dt
    for fmt in _DATE_FMTS:
        try:
            return _dt.strptime(raw, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


# Keep backward-compat alias so lotterycorner.py / lotteryusa.py imports work
_parse_date = _parse_date_text


def _extract_date(container: Tag) -> str | None:
    """Try common date locations inside a container element."""
    t = container.find("time")
    if t:
        raw = t.get("datetime") or t.get_text(strip=True)
        r = _parse_date_text(str(raw))
        if r:
            return r

    for el in container.find_all(
        class_=re.compile(r"\bdate\b|\bday\b|\bwhen\b", re.I)
    ):
        r = _parse_date_text(el.get_text(strip=True))
        if r:
            return r

    for attr in ("data-date", "data-draw-date", "datetime"):
        val = container.get(attr)
        if val:
            r = _parse_date_text(str(val))
            if r:
                return r

    return None


def _extract_inline_number(container: Tag, game_type: str) -> str | None:
    """Scan a container for a winning number of the expected length."""
    expected = 3 if game_type == "pick3" else 4

    for el in container.find_all(
        class_=re.compile(r"number|result|winning|pick|ball|digit", re.I)
    ):
        num = normalize_number(el.get_text(strip=True))
        if len(num) == expected:
            return num

    for text in container.stripped_strings:
        num = normalize_number(text)
        if len(num) == expected:
            return num

    return None


def _valid_length(number: str, game_type: str) -> bool:
    if not number or not number.isdigit():
        return False
    return len(number) == (3 if game_type == "pick3" else 4)


def _is_valid_number(number: str, game_type: str) -> bool:
    """Alias used by lotterycorner.py / lotteryusa.py."""
    return _valid_length(number, game_type)


def _table_headers(table: Tag) -> list[str]:
    thead = table.find("thead")
    row = (thead or table).find("tr")
    if not row:
        return []
    return [th.get_text(strip=True).lower() for th in row.find_all(["th", "td"])]


def _col_index(headers: list[str], keywords: tuple) -> int | None:
    for i, h in enumerate(headers):
        if any(k in h for k in keywords):
            return i
    return None


def _make_result(
    mapping: SourceJobMapping,
    draw_date: str,
    draw_time: str,
    winning_number: str,
    url: str,
    scraped_at: str,
    raw_label: str = "",
) -> RawDrawResult:
    return RawDrawResult(
        state=mapping.job_def.state,
        game_type=mapping.job_def.game_type,
        draw_date=draw_date,
        draw_time=draw_time,
        winning_number=winning_number,
        source_name=SourceName.LOTTERY_NET,
        source_priority=SOURCE_PRIORITIES[SourceName.LOTTERY_NET],
        source_url=url,
        raw_draw_time_label=raw_label,
        scraped_at=scraped_at,
    )
